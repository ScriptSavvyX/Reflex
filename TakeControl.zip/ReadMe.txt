NoRecoil created mainly for the R6. New characters coming soon!
check: ScriptSavvyX.github.io
pass: savvyx
