Just download, unpack and run. We play in place and hold left alt. When someone runs, the program will start holding down the left mouse button.
check: ScriptSavvyX.github.io
pass: savvyx
